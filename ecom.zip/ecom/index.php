<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LooksMart | Online Shopping Site for Men</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Delius Swash Caps' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Andika' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/vaakash/socializer@f4c4e9/css/socializer.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.4.2/css/all.css">
    <script src="https://unpkg.com/scrollreveal"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!--FONT AWESOME-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!--GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet">

</head>

<body style="margin-bottom:200px">
    <!--Header-->
    <?php
    include 'includes/header_menu.php';
    include 'includes/check-if-added.php';
    ?>
    <!--Header ends-->
    <div class="sr-sharebar sr-sb-vl sr-sb-left"><div class="socializer" data-features="32px,circle,opacity,vertical,icon-white,pad" data-sites="facebook,email,whatsapp,github,discord" data-meta-link="" data-meta-title=""></div></div>
    <div id="content">
        <div id="bg">
            <div class="container" style="padding-top:150px">
                <div class="mx-auto p-5 text-white" id="banner_content" style="border-radius: 0.5rem;">
                    <h1 class="caption">We Sell Happiness :)</h1>
                    <p class="offer">
                        <marquee>Flat 40% OFF on premium brands!</marquee>
                    </p>
                    <a href="products.php" class="shopbtn btn btn-lg text-white">Shop Now</a>
                </div>
            </div>

        </div>
    </div>
    <div class="midhead text-center pt-4 h3">
        <b>* Shopping till your wallet says stop *</b>
    </div>
    <!--menu highlights start-->
    <div id="cards_landscape_wrap-2">
        <div class="container">
            <div class="row">
                <div class=" one col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="products.php#watch">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src="images/watch.jpg" alt="" />
                                </div>
                                <div class="text-container">
                                    <h6>Watches</h6>

                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=" two col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="products.php#shirt">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src="images/shirt1N.jpg" alt="" />
                                </div>
                                <div class="text-container">
                                    <h6>Clothing</h6>

                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="three col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="products.php#shoes">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src="images/shoes.jpg" alt="" />
                                </div>
                                <div class="text-container">
                                    <h6>Shoes</h6>

                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=" four col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="products.php#headphones">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src="images/headphones.jpg" alt="" />
                                </div>
                                <div class="text-container">
                                    <h6>Headphones</h6>

                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--menu highlights end-->
    <!--footer -->
    <?php include 'includes/footer.php' ?>
    <!--footer end-->
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/vaakash/socializer@f4c4e9/js/socializer.min.js"></script>
<script>
    $(document).ready(function () {
        $('[data-toggle="popover"]').popover();
    });
    $(document).ready(function () {

        if (window.location.href.indexOf('#login') != -1) {
            $('#login').modal('show');
        }

    });
    (function(){
    socializer( '.socializer' );
}());
    ScrollReveal({
        reset: true,
        distance: '120px',
        duration: 2500,
        delay: 400
    });
    ScrollReveal().reveal('.caption', { delay: 200, origin: 'top' });
    ScrollReveal().reveal('.offer', { delay: 200, origin: 'left' });
    ScrollReveal().reveal('.shopbtn', { delay: 200, origin: 'right' });
    ScrollReveal().reveal('.midhead', { delay: 300, origin: 'bottom' });
    ScrollReveal().reveal('.one', { delay: 400, origin: 'left' });
    ScrollReveal().reveal('.two', { delay: 400, origin: 'bottom' });
    ScrollReveal().reveal('.three', { delay: 400, origin: 'top' });
    ScrollReveal().reveal('.four', { delay: 400, origin: 'right' });
</script>

<?php if (isset($_GET['error'])) {
    $z = $_GET['error'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#signup').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";
} ?>

<?php if (isset($_GET['errorl'])) {
    $z = $_GET['errorl'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#login').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";
} ?>

</html>