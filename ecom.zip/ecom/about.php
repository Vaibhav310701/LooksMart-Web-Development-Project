<?php
require("includes/common.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Planet Shopify | Online Shopping Site for Men</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Delius Swash Caps' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Andika' rel='stylesheet'>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/vaakash/socializer@f4c4e9/css/socializer.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.4.2/css/all.css">
  <script src="https://unpkg.com/scrollreveal"></script>
</head>

<body style="overflow-x:hidden; padding-bottom:100px;">
  <?php
  include 'includes/header_menu.php';
  ?>
   <div class="container mt-3 pt-5">
        <div class="row">
            <div class="col-md-6">
                <div class="thumbnail1">
                    <img src="images/abt.jpg" alt="Lights" style="width:80%" height="500px">
                </div>
            </div>
            <div class="col-md-6">
                <div class="thumbnail">
                    <div class="caption">
                        <h3 class="text-center pt-5"><b>About Us :)</b></h3>
                        <p class="text-center">
                            Looking for a way to make your summer vacations even more memorable? At ABC Bank, we're
                            proud to offer our exclusive vacation program, designed to help you make the most of your
                            time off. With our program, you can enjoy special discounts and perks at top vacation
                            destinations around the world. Whether you're looking to lounge on a tropical beach, explore
                            a new city, or hit the slopes, we've got you covered. Plus, as a ABC Bank customer, you'll
                            earn rewards points on all your travel purchases, which you can redeem for even more savings
                            on future vacations. So why wait? Start planning your dream vacation today and make the most
                            of your time off with ABC Bank.
                        </p>
                        <div class="sr-sharebar sr-sb-vl sr-sb-left"><div class="socializer" data-features="32px,circle,opacity,vertical,icon-white,pad" data-sites="facebook,email,whatsapp,github,discord" data-meta-link="" data-meta-title=""></div></div>
                        <a href="#">Find out more ></a>
                    </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-6">
                <div class="thumbnail">
                    <div class="caption">
                        <h3 class="text-center"><b>Elevate Your Wardrobe with Distinctive Style!</b></h3>
                        <p class="text-center">

At LooksMart, we understand that every man deserves a wardrobe that reflects his unique personality and style. Our journey began with a passion for curating a collection that speaks to the modern man's diverse tastes, preferences, and lifestyles. Established in [2024], LooksMart has quickly become the go-to destination for fashion-conscious men seeking quality, trendsetting apparel and accessories. Our vision at LooksMmart is to redefine the shopping experience for men by offering a carefully curated selection of clothing and accessories that effortlessly blend style, comfort, and quality craftsmanship. Whether you're navigating the urban jungle, making power moves in the boardroom, or enjoying a casual weekend with friends, LooksMart is your ultimate style companion.
Embark on a style journey with LooksMart and become part of a community that celebrates individuality, confidence, and self-expression. Follow us on social media, engage with our style tips, and share your #ManStyleMoments. Discover the essence of true gentlemanly fashion at ManStyleHub – Where Every Man Finds His Signature Style.

Thank you for choosing LooksMart. Elevate your style, and embrace the confidence that comes with dressing well.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="thumbnail2">
                    <div class="caption">
                        <img src="images/abt2.jpg" alt="Lights" style="width:80%" height="500px">
                    </div>
                </div>
            </div>
        </div>
    </div>
  <div class="container pb-3">
  </div>
  <div class="container mt-3 d-flex justify-content-center card pb-3 col-md-6">

    <form class="col-md-12" action="https://formspree.io/EnterYourEmail" method="POST" name="_next">
      <h3 class="text-warning pt-3 title mx-auto">Contact Form</h3>
      <div class="form-group">
        <label for="exampleFormControlInput1">Email address</label>
        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Email" name="email">
      </div>

      <div class="form-group">
        <label for="exampleFormControlTextarea1">Message</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" name="message" rows="5"></textarea>
      </div>
      <input type="hidden" name="_next" value="http://localhost/foody/about.php" />
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>

  <div class="container mt-4 mb-3 bg-light">
        <div class="end">
            <div class="cap text-center">
                <h4><b>Need Some Additional Help.</b></h4>
            </div>
            <div class="container mt-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="thumbnail border p-5 text-center">
                          <h4><b>Find Quick Answer</b></h4>
                          <a href="#">Browser Our FAQ</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail border p-5 text-center">
                            <h4><b>Contact Us</b></h4>
                            <a href="#">By Email Or Phone</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail border p-5 text-center">
                            <h4><b>Self Sevvice Forms.</b></h4>
                            <a href="#">View Our Customer Service Page.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


  </div>
  <!--footer -->
  <?php include 'includes/footer.php' ?>
  <!--footer end-->


</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/vaakash/socializer@f4c4e9/js/socializer.min.js"></script>
<script>
(function(){
    socializer( '.socializer' );
}());
  $(document).ready(function() {
    $('[data-toggle="popover"]').popover();
  });
  $(document).ready(function() {

    if (window.location.href.indexOf('#login') != -1) {
      $('#login').modal('show');
    }

  });
  ScrollReveal({
        reset: true,
        distance: '800px',
        duration: 2500,
        delay: 400
    });
    ScrollReveal().reveal('.thumbnail1', { delay: 200, origin: 'right' });
    ScrollReveal().reveal('.thumbnail2', { delay: 200, origin: 'top' });
</script>
<?php if (isset($_GET['error'])) {
  $z = $_GET['error'];
  echo "<script type='text/javascript'>
$(document).ready(function(){
$('#signup').modal('show');
});
</script>";
  echo "
<script type='text/javascript'>alert('" . $z . "')</script>";
} ?>
<?php if (isset($_GET['errorl'])) {
  $z = $_GET['errorl'];
  echo "<script type='text/javascript'>
$(document).ready(function(){
$('#login').modal('show');
});
</script>";
  echo "
<script type='text/javascript'>alert('" . $z . "')</script>";
} ?>

</html>